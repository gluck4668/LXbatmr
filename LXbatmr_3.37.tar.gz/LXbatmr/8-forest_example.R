
library(LXbatmr)


rm(list=ls())

devtools::load_all()

or_file ="D:/Desktop/LXbatmr 2024-10-08(v3.36)/finngen_R10/finngen_R10_NAFLD_outcome_mr_all.xlsx"

# mr_method=c("Inverse variance weighted","MR Egger")     #选择展示的方法

mr_method=c("Inverse variance weighted")

#---------------------------------
forest_plot(or_file,mr_method)
