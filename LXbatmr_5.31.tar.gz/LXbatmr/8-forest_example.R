
library(LXbatmr)


rm(list=ls())

devtools::load_all()

or_file ="D:/Desktop/LXbatmr_shiny 2024-10-14/drug_MR_results_2024-10-13  233/significant_drugMR_mr.xlsx"

# mr_method=c("Inverse variance weighted","MR Egger")     #选择展示的方法

mr_method=c("Inverse variance weighted")

#---------------------------------
forest_plot(or_file,mr_method)
