
LXdrugMR <- function(){

#-------R packages ----------------------
inst_packages ()

#---create dir----------------------------
dir_save <- paste0("drug_MR_results_",Sys.Date())
if(!dir.exists(dir_save))
    dir.create(dir_save)

#---data information----------------------
exp_files <- dir(exp_data,full.names = T)
target_gene_df <- read.xlsx(target_gene_data)
out_files <- out_data

#-----read exposure data file-----
x=1

exp_file_x <- exp_files[x]

exp_file_type <- tools::file_ext(exp_file_x)  # 文件扩展名

if(tolower(exp_file_type)=="gz")
  exp_df <- fread(exp_file_x) else
  {if(tolower(exp_file_type)=="txt")
    exp_df <- read_table(exp_file_x) else
      exp_df <- eval(str2expression( paste0("read.",exp_file_type,"('",exp_file_x,"')")
                ))
  }

#-----筛选exp data-----
exp_df <- eval(str2expression(paste0("distinct(exp_df,",snp_exp,",.keep_all = T)"))) #snp去重
exp_df <-eval(str2expression(paste0("subset(exp_df,",pval_exp,"<",exp_p,")"))) #筛选p值

if(nrow(exp_df)>0)
  print(paste0("Note: At the condition of exp_p<",exp_p,", there are ",nrow(exp_df), " SNPs.")) else
    stop(paste0("Note: At the condition of exp_p<",exp_p,", there is no SNP."))

#---save the exp data---
exp_file_name <- str_extract(exp_file_x,"(?<=\\/)[^/]+$") %>% str_extract(".*?(?=[.])")

exp_file_save <- paste0(dir_save,"/",exp_file_name,".csv")
write.csv(exp_df,exp_file_save,row.names = F)

#----format the exposure data-----
exp_df <- read_exposure_data(filename = exp_file_save,
                             sep = ",",
                             chr_col = chr_exp,
                             pos_col = pos_exp,
                             snp_col = snp_exp,
                             beta_col = beta_exp,
                             se_col = se_exp,
                             effect_allele_col = effect_allele_exp,
                             other_allele_col = other_allele_exp,
                             eaf_col = eaf_exp,
                             pval_col = pval_exp)

exp_df$id.exposure <- exp_file_name

#------exposure beta and OR transformation---------
if(!grepl("log",beta_exp,ignore.case = T) | !grepl("ln",beta_exp,ignore.case = T)){
  if(grepl("odd",beta_exp,ignore.case = T) | grepl("OR",beta_exp,ignore.case = T)){
    exp_df <- exp_df %>% as.data.frame()
    exp_df$beta.exposure <- log(as.numeric(exp_df$beta.exposure))
    }
  }

#-------Linkage Disequilibrium (LD) test--------
ld_clum <- exp_ld_clum(exp_df,clump_kb,clump_r2)
exp_df <- ld_clum$exp_clum

#----target gene SNP---------------------------
y=1

target_y <- target_gene_df[y,]

target_gene <- target_y[1,1]
chr_target <- target_y[1,2]
pos_start <- target_y[1,3]
pos_end <- target_y[1,4]

target_gene_snp <- subset(exp_df,chr.exposure==chr_target & pos.exposure>pos_start-100000 & pos.exposure<pos_end+100000)

if(nrow(target_gene_snp)==0)
  stop(paste0("Note: The '",exp_file_name, "' dataset didn't have any SNPs for the target gene (",target_gene,")"))

target_gene_name <- paste0(dir_save,"/",target_gene," snp.csv")
write.csv(target_gene_snp,target_gene_name)





#---MR data (gz,vcf.gz,csv,txt format)-----------------------------------------

mr_data <- mr_df$mr_data

#---MR analysis----------------------------------------------------------------
mr_analysis <- mr_analysis(mr_data)

print("The results can be found in the folder of <analysis results> ")


#---BWMR analysis--------------------------------------------------------------
print("begin the BWMR analysis......")
bwmr_analysis <- bwmr_analysis(mr_data,exposure_name,outcome_name)
print("The BWMR analysis is done......")

#--- show one of the plot of BWMR analysis----
bwmr_analysis$result

}
