
library(LXbatmr)


rm(list=ls())

devtools::load_all()

or_file ="D:/Desktop/LXbatmr 2024-10-08(v3.36)/finngen_R10_NAFLD (bat_mr_results)_2024-10-09/finngen_R10_NAFLD_outcome_mr_all_significant.xlsx"

mr_method=c("Inverse variance weighted","MR Egger")     #选择展示的方法

# devtools::load_all()

#---------------------------------
forest_plot(or_file,mr_method)
